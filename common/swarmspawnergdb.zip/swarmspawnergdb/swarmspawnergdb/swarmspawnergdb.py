# Subclassing to solve this problem: https://github.com/jupyterhub/dockerspawner/issues/330
# Modifies functions in https://github.com/jupyterhub/dockerspawner/blob/master/dockerspawner/swarmspawner.py#L257

from dockerspawner import SwarmSpawner
from tornado import gen
from pprint import pformat

class SwarmSpawnerGDB(SwarmSpawner):
    
    @gen.coroutine
    def get_task(self):
        self.log.debug("Getting task of service '%s'", self.service_name)
        if self.get_object() is None:
            return None

        try:
            tasks = yield self.docker(
                "tasks",
                filters={"service": self.service_name, "desired-state": "running"},
            )
            if len(tasks) == 0:
                # START - Test if any services exist and, if they do, return them
                tasks = yield self.docker(
                    "tasks",
                    filters={"service": self.service_name},
                )
                # END
                if len(tasks) == 0:
                    return None

            elif len(tasks) > 1:
                raise RuntimeError(
                    "Found more than one running notebook task for service '{}'".format(
                        self.service_name
                    )
                )

            task = tasks[0]
        except APIError as e:
            if e.response.status_code == 404:
                self.log.info("Task for service '%s' is gone", self.service_name)
                task = None
            else:
                raise

        return task




    @gen.coroutine
    def start_object(self):
        """Not actually starting anything
        but use this to wait for the container to be running.
        Spawner.start shouldn't return until the Spawner
        believes a server is *running* somewhere,
        not just requested.
        """

        dt = 1.0

        while True:
            service = yield self.get_task()
            if not service:
                raise RuntimeError("Service %s not found" % self.service_name)

            status = service["Status"]
            state = status["State"].lower()
            self.log.debug("Service %s state: %s", self.service_id[:7], state)
            if state in {"new", "assigned", "accepted", "starting", "pending", "preparing", "rejected"}: # Added
                # not ready yet, wait before checking again
                yield gen.sleep(dt)
                # exponential backoff
                dt = min(dt * 1.5, 11)
            else:
                break
        if state != "running":
            raise RuntimeError(
                "Service %s not running: %s" % (self.service_name, pformat(status))
            )
