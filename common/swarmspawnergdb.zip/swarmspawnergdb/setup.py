from setuptools import setup
import os

here = os.path.abspath(os.path.dirname(__file__))
version_ns = {}
with open(os.path.join(here, 'swarmspawnergdb', '_version.py')) as f:
    exec(f.read(), {}, version_ns)

setup(name='swarmspawnergdb',
      version=version_ns['__version__'],
      description='a clone of swarmspawner with the get_tasks() function replaced to deal with some errors.',
      url='http://github.com/gdbassett',
      author='Gabriel Bassett',
      author_email='gabe@infosecanalytics.com',
      license='none',
      packages=['swarmspawnergdb'],
      zip_safe=False)